     <?php 
     require_once("./views/layout/inc/header.inc.php");
     ?>

    <div id="main" class="d-flex justify-content-center align-items-center">

          <?php echo  $content_for_layout?>
    </div>

    <?php require_once('./views/layout/inc/footer.inc.php')?>